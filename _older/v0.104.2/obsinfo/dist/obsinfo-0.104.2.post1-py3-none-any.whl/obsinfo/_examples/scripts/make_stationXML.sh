#!/bin/bash

CAMPAIGN_DIR="../Information_Files/campaigns/MYCAMPAIGN"

obsinfo-makeSTATIONXML "$CAMPAIGN_DIR/MYCAMPAIGN.INSU-IPGP.network.yaml" -d STATIONXMLs
