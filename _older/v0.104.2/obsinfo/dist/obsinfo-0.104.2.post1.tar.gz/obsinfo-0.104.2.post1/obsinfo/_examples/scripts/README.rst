========================================================
OBSINFO example scripts
========================================================

Examples of using obsinfo console scripts to:

* validate the information files
* print basic contents of the information files
* create STATIONXML files