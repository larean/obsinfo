========================================================
OBSINFO add-on scripts
========================================================

Contains scripts for add-ons to obsinfo (the scripts use software
that is not distributed with obsinfo)

* Generate data creation process-scripts using the SDPCHAIN and LC2MS
  software suites
