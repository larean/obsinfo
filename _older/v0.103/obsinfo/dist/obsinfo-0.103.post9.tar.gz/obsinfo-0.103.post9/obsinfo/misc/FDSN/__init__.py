from .network_info import network_info
from .equipment_type import equipment_type