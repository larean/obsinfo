Examples of using the obsinfo scripts to:
  - validate the information files
  - print basic contents of the information files
  - create STATIONXML files